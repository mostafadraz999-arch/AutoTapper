package com.example.autotapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: Thread? = null
    @Volatile private var running = false

    private var myHsv = FloatArray(3)
    private var foeHsv = FloatArray(3)
    private var apiKey = ""
    private var joyX = 0f; private var joyY = 0f
    private var shootX = 0f; private var shootY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        startAsForeground()

        myHsv = Vision.hsv(Color.parseColor(intent.getStringExtra("team") ?: "#FF0000"))
        foeHsv = Vision.hsv(Color.parseColor(intent.getStringExtra("foe") ?: "#0000FF"))
        apiKey = intent.getStringExtra("key") ?: ""
        joyX = intent.getFloatExtra("jx", 200f); joyY = intent.getFloatExtra("jy", 800f)
        shootX = intent.getFloatExtra("sx", 2000f); shootY = intent.getFloatExtra("sy", 800f)

        val code = intent.getIntExtra("code", 0)
        val data: Intent = intent.getParcelableExtra("data") ?: run { stopSelf(); return START_NOT_STICKY }

        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopAll() }
        }, Handler(Looper.getMainLooper()))

        val dm = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "cap", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )

        running = true
        thread = Thread { loop() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "AutoTapper", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "cap")
            .setContentTitle("AutoTapper is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val p = img.planes[0]
            val rowPad = p.rowStride - p.pixelStride * img.width
            val bmp = Bitmap.createBitmap(img.width + rowPad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(p.buffer)
            return if (rowPad == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
        } finally {
            img.close()
        }
    }

    private fun loop() {
        var lastClaude = 0L
        var lastShot = 0L
        val ds = 4
        while (running) {
            try {
                val full = grab()
                val svc = TapService.instance
                if (full != null && svc != null) {
                    val small = Bitmap.createScaledBitmap(full, full.width / ds, full.height / ds, false)
                    val mine = Vision.blobs(small, myHsv)
                    val foes = Vision.blobs(small, foeHsv)
                    val now = System.currentTimeMillis()
                    if (mine.size >= 3 && foes.isNotEmpty()) {
                        // In a match: move the joystick toward the opponents' side, shoot when close.
                        val mx = mine.map { it.x }.average().toFloat() * ds
                        val my = mine.map { it.y }.average().toFloat() * ds
                        val fx = foes.map { it.x }.average().toFloat() * ds
                        val fy = foes.map { it.y }.average().toFloat() * ds
                        val dx = fx - mx
                        val dy = fy - my
                        val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
                        svc.swipe(joyX, joyY, joyX + dx / len * 120f, joyY + dy / len * 120f, 220)
                        if (len < full.width * 0.25f && now - lastShot > 1500) {
                            lastShot = now
                            svc.tap(shootX, shootY)
                        }
                    } else if (apiKey.isNotBlank() && now - lastClaude > 5000) {
                        // Menu / unknown screen: ask Claude what to tap.
                        lastClaude = now
                        val a = ClaudeClient.ask(apiKey, full)
                        if (a != null) svc.tap(a.x, a.y)
                    }
                }
            } catch (e: Exception) {
                // keep going
            }
            try { Thread.sleep(250) } catch (e: InterruptedException) { return }
        }
    }

    private fun stopAll() {
        if (!running && projection == null) return
        running = false
        thread?.interrupt()
        display?.release(); display = null
        reader?.close(); reader = null
        val p = projection; projection = null
        try { p?.stop() } catch (e: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { stopAll(); super.onDestroy() }
}
