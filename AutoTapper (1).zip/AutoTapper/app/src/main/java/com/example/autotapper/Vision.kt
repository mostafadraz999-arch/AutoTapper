package com.example.autotapper

import android.graphics.Bitmap
import android.graphics.Color

object Vision {
    data class Blob(val x: Float, val y: Float, val size: Int)

    fun hsv(color: Int): FloatArray = FloatArray(3).also { Color.colorToHSV(color, it) }

    /** Finds clusters of pixels close to the target color (HSV). Coordinates are in bitmap pixels. */
    fun blobs(bmp: Bitmap, target: FloatArray, minSize: Int = 6): List<Blob> {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val mask = BooleanArray(w * h)
        val c = FloatArray(3)
        val ignoreHue = target[1] < 0.15f
        for (i in px.indices) {
            Color.colorToHSV(px[i], c)
            var dh = Math.abs(c[0] - target[0])
            if (dh > 180f) dh = 360f - dh
            mask[i] = (ignoreHue || dh < 15f) &&
                Math.abs(c[1] - target[1]) < 0.30f &&
                Math.abs(c[2] - target[2]) < 0.35f
        }
        val out = ArrayList<Blob>()
        val queue = IntArray(w * h)
        for (start in mask.indices) {
            if (!mask[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            mask[start] = false
            var sx = 0L
            var sy = 0L
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                sx += x
                sy += y
                if (x > 0 && mask[p - 1]) { mask[p - 1] = false; queue[tail++] = p - 1 }
                if (x < w - 1 && mask[p + 1]) { mask[p + 1] = false; queue[tail++] = p + 1 }
                if (y > 0 && mask[p - w]) { mask[p - w] = false; queue[tail++] = p - w }
                if (y < h - 1 && mask[p + w]) { mask[p + w] = false; queue[tail++] = p + w }
            }
            if (tail >= minSize) out.add(Blob(sx.toFloat() / tail, sy.toFloat() / tail, tail))
        }
        return out
    }
}
