package com.example.autotapper

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object ClaudeClient {
    data class Action(val kind: String, val x: Float, val y: Float)

    private const val MODEL = "claude-sonnet-5-5"
    private const val MAX_W = 1280

    /** Sends a screenshot to Claude and returns a tap action in FULL-bitmap pixel coordinates (or null). */
    fun ask(apiKey: String, full: Bitmap): Action? {
        val scale = if (full.width > MAX_W) MAX_W.toFloat() / full.width else 1f
        val img = if (scale < 1f)
            Bitmap.createScaledBitmap(full, MAX_W, (full.height * scale).toInt(), true) else full
        val baos = ByteArrayOutputStream()
        img.compress(Bitmap.CompressFormat.JPEG, 70, baos)
        val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)

        val prompt = "This is a screenshot (${img.width}x${img.height} px) of the eFootball mobile game, " +
            "currently NOT in active gameplay (menu, loading, result or similar screen). " +
            "Reply with ONLY a JSON object. To continue toward starting or finishing a match " +
            "(buttons like Next, OK, Skip, Continue, Kick Off, Match), reply " +
            "{\"action\":\"tap\",\"x\":<int>,\"y\":<int>} using pixel coordinates of this image. " +
            "NEVER tap anything related to purchases, store, coins, or paid items. " +
            "If unsure, reply {\"action\":\"none\"}."

        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source",
                JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)))
            .put(JSONObject().put("type", "text").put("text", prompt))
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 200)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode != 200) return null
            val resp = conn.inputStream.bufferedReader().readText()
            val text = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
            val json = JSONObject(text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1))
            if (json.optString("action") != "tap") return null
            return Action("tap", json.getInt("x") / scale, json.getInt("y") / scale)
        } finally {
            conn.disconnect()
        }
    }
}
