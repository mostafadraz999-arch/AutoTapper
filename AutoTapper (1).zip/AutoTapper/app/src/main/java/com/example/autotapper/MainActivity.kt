package com.example.autotapper

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val fields = LinkedHashMap<String, EditText>()

    private fun addField(root: LinearLayout, key: String, label: String, def: String, secret: Boolean = false) {
        root.addView(TextView(this).apply { text = label })
        val e = EditText(this).apply {
            setText(prefs.getString(key, def))
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        fields[key] = e
        root.addView(e)
    }

    private fun v(key: String) = fields[key]!!.text.toString().trim()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 32, 48, 32) }

        root.addView(Button(this).apply {
            text = "1) Enable Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        addField(root, "team", "My team shirt color (hex)", "#FF0000")
        addField(root, "foe", "Opponent shirt color (hex)", "#0000FF")
        addField(root, "jx", "Joystick center X", "250")
        addField(root, "jy", "Joystick center Y", "800")
        addField(root, "sx", "Shoot button X", "2000")
        addField(root, "sy", "Shoot button Y", "800")
        addField(root, "key", "Anthropic API key (optional, for menus)", "", secret = true)

        root.addView(Button(this).apply {
            text = "2) Start bot"
            setOnClickListener {
                if (TapService.instance == null) {
                    Toast.makeText(this@MainActivity, "Enable the accessibility service first", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val ed = prefs.edit()
                fields.forEach { (k, e) -> ed.putString(k, e.text.toString().trim()) }
                ed.apply()
                val mgr = getSystemService(MediaProjectionManager::class.java)
                startActivityForResult(mgr.createScreenCaptureIntent(), 1)
            }
        })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK || data == null) return
        val i = Intent(this, CaptureService::class.java).apply {
            putExtra("code", resultCode)
            putExtra("data", data)
            putExtra("team", v("team")); putExtra("foe", v("foe")); putExtra("key", v("key"))
            putExtra("jx", v("jx").toFloatOrNull() ?: 250f); putExtra("jy", v("jy").toFloatOrNull() ?: 800f)
            putExtra("sx", v("sx").toFloatOrNull() ?: 2000f); putExtra("sy", v("sy").toFloatOrNull() ?: 800f)
        }
        startForegroundService(i)
        Toast.makeText(this, "Bot started. Switch to the game.", Toast.LENGTH_LONG).show()
    }
}
